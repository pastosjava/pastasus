package me.pastas.pastasus.gui;

import me.pastas.pastasus.PastaSus;
import me.pastas.pastasus.models.SusPlayer;
import me.pastas.pastasus.utils.ColorUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;

public class SusGUI {

    private final PastaSus plugin;

    public SusGUI(PastaSus plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {

        Inventory gui = Bukkit.createInventory(
                null,
                plugin.getConfig().getInt("gui.size"),
                ColorUtil.color(
                        plugin.getConfig().getString("gui.title")
                )
        );

        for (SusPlayer sus : plugin.getSusManager().getSusPlayers()) {

            ItemStack head = new ItemStack(Material.PLAYER_HEAD);

            SkullMeta meta = (SkullMeta) head.getItemMeta();

            meta.setOwningPlayer(
                    Bukkit.getOfflinePlayer(sus.getUuid())
            );

            meta.displayName(
                    ColorUtil.color("<red>" + sus.getName())
            );

            List<Component> lore = new ArrayList<>();

            for (String line : plugin.getConfig()
                    .getStringList("gui.lore")) {

                lore.add(ColorUtil.color(
                        line.replace("%check%", sus.getCheck())
                                .replace("%vl%",
                                        String.valueOf(sus.getVl()))
                ));
            }

            meta.lore(lore);

            head.setItemMeta(meta);

            gui.addItem(head);
        }

        player.openInventory(gui);

        playOpenSound(player);
    }

    private void playOpenSound(Player player) {

        if (!plugin.getConfig()
                .getBoolean("sounds.enabled")) {
            return;
        }

        String path = "sounds.open-gui.";

        Sound sound = Sound.valueOf(
                plugin.getConfig().getString(path + "sound")
        );

        float volume = (float) plugin.getConfig()
                .getDouble(path + "volume");

        float pitch = (float) plugin.getConfig()
                .getDouble(path + "pitch");

        player.playSound(
                player.getLocation(),
                sound,
                volume,
                pitch
        );
    }
}