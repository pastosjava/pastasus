package me.pastas.pastasus.models;

import java.util.UUID;

public class SusPlayer {

    private final UUID uuid;
    private final String name;

    private final String check;
    private final int vl;

    public SusPlayer(UUID uuid, String name, String check, int vl) {

        this.uuid = uuid;
        this.name = name;
        this.check = check;
        this.vl = vl;
    }

    public UUID getUuid() {
        return uuid;
    }

    public String getName() {
        return name;
    }

    public String getCheck() {
        return check;
    }

    public int getVl() {
        return vl;
    }
}