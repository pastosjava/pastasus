package me.pastas.pastasus.listeners;

import me.pastas.pastasus.PastaSus;
import me.pastas.pastasus.utils.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

public class InventoryListener implements Listener {

    private final PastaSus plugin;

    public InventoryListener(PastaSus plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {

        if (!event.getView().title()
                .equals(ColorUtil.color(
                        plugin.getConfig()
                                .getString("gui.title")))) {
            return;
        }

        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        ItemStack item = event.getCurrentItem();

        if (item == null) return;

        if (!(item.getItemMeta() instanceof SkullMeta meta)) {
            return;
        }

        if (meta.getOwningPlayer() == null) {
            return;
        }

        Player target = Bukkit.getPlayer(
                meta.getOwningPlayer().getUniqueId()
        );

        if (target == null) {
            return;
        }

        player.teleport(target);

        plugin.getMessageManager().send(
                player,
                plugin.getConfig()
                        .getString("messages.teleported")
                        .replace("%player%",
                                target.getName())
        );

        playTeleportSound(player);

        player.closeInventory();
    }

    private void playTeleportSound(Player player) {

        if (!plugin.getConfig()
                .getBoolean("sounds.enabled")) {
            return;
        }

        String path = "sounds.teleport.";

        Sound sound = Sound.valueOf(
                plugin.getConfig().getString(path + "sound")
        );

        float volume = (float) plugin.getConfig()
                .getDouble(path + "volume");

        float pitch = (float) plugin.getConfig()
                .getDouble(path + "pitch");

        player.playSound(
                player.getLocation(),
                sound,
                volume,
                pitch
        );
    }
}