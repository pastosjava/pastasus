package me.pastas.pastasus.commands;

import me.pastas.pastasus.PastaSus;
import me.pastas.pastasus.gui.SusGUI;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SusCommand implements CommandExecutor {

    private final PastaSus plugin;

    public SusCommand(PastaSus plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender,
                             Command command,
                             String label,
                             String[] args) {

        if (!(sender instanceof Player player)) {
            return true;
        }

        if (!player.hasPermission("pastasus.use")) {

            plugin.getMessageManager().send(
                    player,
                    plugin.getConfig()
                            .getString("messages.no-permission")
            );

            return true;
        }

        if (args.length == 1
                && args[0].equalsIgnoreCase("reload")) {

            if (!player.hasPermission("pastasus.admin")) {
                return true;
            }

            plugin.reloadConfig();

            plugin.getMessageManager().send(
                    player,
                    plugin.getConfig()
                            .getString("messages.reload")
            );

            return true;
        }

        new SusGUI(plugin).open(player);

        return true;
    }
}