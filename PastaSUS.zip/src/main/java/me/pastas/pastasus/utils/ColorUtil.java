package me.pastas.pastasus.utils;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.ChatColor;

public class ColorUtil {

    public static Component color(String text) {

        text = ChatColor.translateAlternateColorCodes('&', text);

        return MiniMessage.miniMessage().deserialize(text);
    }

    public static String colorString(String text) {

        return ChatColor.translateAlternateColorCodes('&', text);
    }
}