package me.pastas.pastasus.managers;

import me.pastas.pastasus.PastaSus;
import me.pastas.pastasus.models.SusPlayer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class VulcanManager {

    private final PastaSus plugin;

    public VulcanManager(PastaSus plugin) {
        this.plugin = plugin;

        loadExampleData();
    }

    // Replace this later with actual Vulcan API

    private void loadExampleData() {

        Bukkit.getScheduler().runTaskTimer(
                plugin,
                () -> {

                    for (Player player : Bukkit.getOnlinePlayers()) {

                        int fakeVl = (int) (Math.random() * 20);

                        if (fakeVl < plugin.getConfig()
                                .getInt("vulcan.minimum-vl")) {
                            continue;
                        }

                        plugin.getSusManager().addSusPlayer(
                                new SusPlayer(
                                        player.getUniqueId(),
                                        player.getName(),
                                        "KillAura",
                                        fakeVl
                                )
                        );
                    }

                },
                20L,
                100L
        );
    }
}