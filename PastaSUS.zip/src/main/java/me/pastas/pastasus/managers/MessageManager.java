package me.pastas.pastasus.managers;

import me.pastas.pastasus.PastaSus;
import me.pastas.pastasus.utils.ColorUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;

public class MessageManager {

    private final PastaSus plugin;

    public MessageManager(PastaSus plugin) {
        this.plugin = plugin;
    }

    public Component parse(String text) {
        return ColorUtil.color(text);
    }

    public void send(Player player, String message) {

        Component component = parse(
                plugin.getConfig().getString("messages.prefix") + message
        );

        String mode = plugin.getConfig().getString("display-mode");

        if (mode.equalsIgnoreCase("CHAT")
                || mode.equalsIgnoreCase("BOTH")) {

            player.sendMessage(component);
        }

        if (mode.equalsIgnoreCase("ACTIONBAR")
                || mode.equalsIgnoreCase("BOTH")) {

            player.sendActionBar(component);
        }
    }
}