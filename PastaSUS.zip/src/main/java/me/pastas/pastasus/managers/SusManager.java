package me.pastas.pastasus.managers;

import me.pastas.pastasus.PastaSus;
import me.pastas.pastasus.models.SusPlayer;

import java.util.ArrayList;
import java.util.List;

public class SusManager {

    private final PastaSus plugin;

    private final List<SusPlayer> susPlayers = new ArrayList<>();

    public SusManager(PastaSus plugin) {
        this.plugin = plugin;
    }

    public List<SusPlayer> getSusPlayers() {
        return susPlayers;
    }

    public void addSusPlayer(SusPlayer player) {

        susPlayers.removeIf(p ->
                p.getUuid().equals(player.getUuid()));

        susPlayers.add(player);
    }
}