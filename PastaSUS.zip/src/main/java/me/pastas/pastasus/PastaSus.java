package me.pastas.pastasus;

import me.pastas.pastasus.commands.SusCommand;
import me.pastas.pastasus.listeners.InventoryListener;
import me.pastas.pastasus.managers.MessageManager;
import me.pastas.pastasus.managers.SusManager;
import me.pastas.pastasus.managers.VulcanManager;
import org.bukkit.plugin.java.JavaPlugin;

public class PastaSus extends JavaPlugin {

    private static PastaSus instance;

    private MessageManager messageManager;
    private SusManager susManager;
    private VulcanManager vulcanManager;

    @Override
    public void onEnable() {

        instance = this;

        saveDefaultConfig();

        messageManager = new MessageManager(this);
        susManager = new SusManager(this);
        vulcanManager = new VulcanManager(this);

        getCommand("sus").setExecutor(new SusCommand(this));

        getServer().getPluginManager().registerEvents(
                new InventoryListener(this),
                this
        );

        getServer().getConsoleSender().sendMessage(
                messageManager.parse(
                        getConfig().getString("startup.enabled")
                )
        );
    }

    @Override
    public void onDisable() {

        getServer().getConsoleSender().sendMessage(
                messageManager.parse(
                        getConfig().getString("startup.disabled")
                )
        );
    }

    public static PastaSus getInstance() {
        return instance;
    }

    public MessageManager getMessageManager() {
        return messageManager;
    }

    public SusManager getSusManager() {
        return susManager;
    }

    public VulcanManager getVulcanManager() {
        return vulcanManager;
    }
}